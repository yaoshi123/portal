package com.imooc.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.dom4j.DocumentException;

import com.imooc.oauth.SNSUserInfo;
import com.imooc.oauth.WeixinOauth2Token;
import com.imooc.po.TextMessage;
import com.imooc.util.AdvancedUtil;
import com.imooc.util.CheckUtil;
import com.imooc.util.MessageUtil;

public class WeixinServlet extends HttpServlet {
	/**
	 * ������֤
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse resp)
			throws ServletException, IOException {
		String signature = request.getParameter("signature");
		String timestamp = request.getParameter("timestamp");
		String nonce = request.getParameter("nonce");
		String echostr = request.getParameter("echostr");

		PrintWriter out = resp.getWriter();
		if (CheckUtil.checkSignature(signature, timestamp, nonce)) {
			out.print(echostr);
		}
	}

	/**
	 * ��Ϣ�Ľ�������Ӧ
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse resp)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		resp.setCharacterEncoding("UTF-8");
		System.out.println("1ddd");
		PrintWriter out = resp.getWriter();

		// �û�ͬ����Ȩ���ܻ�ȡ��code
		String code = request.getParameter("code");
		String state = request.getParameter("state");
		System.out.println("1ddd"+state);
		// �û�ͬ����Ȩ
//		if (!"authdeny".equals(code)) {
//			// ��ȡ��ҳ��Ȩaccess_token
//			System.out.println("1112"+code);
//			WeixinOauth2Token weixinOauth2Token = AdvancedUtil
//					.getOauth2AccessToken("wxb5b3d0fdb3ed51c6",
//							"4417df0a2c0afcf91e924b5f6a0a4279", code);
//			// ��ҳ��Ȩ�ӿڷ���ƾ֤
//			String accessToken = weixinOauth2Token.getAccessToken();
//			// �û���ʶ
//			String openId = weixinOauth2Token.getOpenId();
//			// ��ȡ�û���Ϣ
//			SNSUserInfo snsUserInfo = AdvancedUtil.getSNSUserInfo(accessToken,
//					openId);
//
//			// ����Ҫ���ݵĲ���
//			request.setAttribute("snsUserInfo", snsUserInfo);
//			request.setAttribute("state", state);
//
//			// ��ת��index.jsp
////			System.out.println(snsUserInfo);
//		}
//		request.getRequestDispatcher("index.jsp").forward(request, resp);

		try {
			Map<String, String> map = MessageUtil.xmlToMap(request);
			String fromUserName = map.get("FromUserName");
			String toUserName = map.get("ToUserName");
			String msgType = map.get("MsgType");
			String content = map.get("Content");

			String message = null;
			// �����ı�
			if (MessageUtil.MESSAGE_TEXT.equals(msgType)) {

				if ("1".equals(content)) {
					content = "您已经开始充电";
				} else if ("2".equals(content)) {
					content = "捷能售电各种介绍。。。。。";
				}
				TextMessage text = new TextMessage();
				text.setFromUserName(toUserName);
				text.setToUserName(fromUserName);
				text.setMsgType("text");
				text.setCreateTime(new Date().getTime());
				text.setContent(content);
				message = MessageUtil.textMessageToXml(text);
				if ("3".equals(content)) {
					message = MessageUtil.initNewsMessage(toUserName,
							fromUserName);
				}

			} else if (MessageUtil.MESSAGE_EVNET.equals(msgType)) {
				String eventType = map.get("Event");
				if (MessageUtil.MESSAGE_SUBSCRIBE.equals(eventType)) {
					message = MessageUtil.initText(toUserName, fromUserName,
							MessageUtil.menuText());
				} else if (MessageUtil.MESSAGE_CLICK.equals(eventType)) {
					message = MessageUtil.initText(toUserName, fromUserName,
							MessageUtil.menuText());
				} else if (MessageUtil.MESSAGE_VIEW.equals(eventType)) {
					String url = map.get("EventKey");
					message = MessageUtil.initText(toUserName, fromUserName,
							url);
				} else if (MessageUtil.MESSAGE_SCANCODE.equals(eventType)) {
					String key = map.get("EventKey");
					message = MessageUtil.initText(toUserName, fromUserName,
							key);
				}
			} else if (MessageUtil.MESSAGE_LOCATION.equals(msgType)) {
				String label = map.get("Label");
				message = MessageUtil.initText(toUserName, fromUserName, label);
			}
			System.out.println(message);
			out.print(message);
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			out.close();
		}

	}
}
