package com.imooc.test;

import net.sf.json.JSONObject;

import com.imooc.po.AccessToken;
import com.imooc.util.WeixinUtil;

public class WeixinTest {
	public static void main(String[] args) {
		try {
			AccessToken token = WeixinUtil.getAccessToken();
			System.out.println("Ʊ��" + token.getToken());
			System.out.println("��Чʱ��" + token.getExpiresIn());

//			// String path = "D:/imooc.jpg";
//			// String mediaId = WeixinUtil.upload(path, token.getToken(),
//			// "thumb");
//			// System.out.println(mediaId);
//			//
//			// String result = WeixinUtil.translate("my name is laobi");
//			// //String result = WeixinUtil.traslateFull("");
//			// System.out.println(result);
//
//			int object = WeixinUtil.deleteMenu(token.getToken());
//			 System.out.println(object);
			String menu = JSONObject.fromObject(WeixinUtil.initMenu())
					.toString();
			int result = WeixinUtil.createMenu(token.getToken(), menu);
			 if(result ==0){
			 System.out.println("�����˵��ɹ�");
			 }else{
			 System.out.println("�����룺"+result);
			 }
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
