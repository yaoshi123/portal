package GetUrl;

import ysq.weixin.dao.impl.WeiXinDaoImpl;
import ysq.weixin.model.useValue;

public class GetUrl {

	public static void main(String[] args) {

		String url = "http://lijiangang.ittun.com/OAUTH/servlet/OAuthAPIServlet";
		WeiXinDaoImpl dao = new WeiXinDaoImpl();
		String pathUrl = null;
		try {
			pathUrl = dao.getCodeUrl(useValue.AppId, url, "snsapi_userinfo",
					"state");
		} catch (Exception e) {

		}
		System.out.println(pathUrl);
	}
}
