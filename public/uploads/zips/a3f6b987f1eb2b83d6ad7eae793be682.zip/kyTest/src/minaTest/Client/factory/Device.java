package minaTest.Client.factory;

import org.apache.mina.core.session.IoSession;

public class Device {
 private String mac;
 private IoSession session;
 private boolean gunStatus=true;//插枪状态
 private boolean loginState=false;//登录状态
 private byte startState=0x01;//开始充电状态
 private boolean stopSuccessState=false;//是否停止状态
 private Long startTime;//开始充电时间
 private byte stopReason=0x00;//0x01：满足条件充满
 
 /*0x02：充电枪连接不正常
 0x03：采集不上数据停止充电
 0x04：急停开关启动停止充电
 0x05：过压保护告警停止充电
 0x06：低压保护告警停止充电
 0x07：过流保护告警停止充电
 0x08：低流保护告警停止充电
 0x09：其他告警停止充电*/

 @Override
public String toString() {
	return "Device [mac=" + mac + ", session=" + session + ", gunStatus="
			+ gunStatus + ", loginState=" + loginState + ", startState="
			+ startState + ", stopSuccessState=" + stopSuccessState
			+ ", startTime=" + startTime + ", stopReason=" + stopReason
			+ ", tradeId=" + tradeId + ", elec=" + elec + "]";
}

private int tradeId;
 private float elec;
 
public String getMac() {
	return mac;
}

public boolean isGunStatus() {
	return gunStatus;
}

public void setGunStatus(boolean gunStatus) {
	this.gunStatus = gunStatus;
}

public boolean isLoginState() {
	return loginState;
}

public void setLoginState(boolean loginState) {
	this.loginState = loginState;
}



public void setMac(String mac) {
	this.mac = mac;
}

public IoSession getSession() {
	return session;
}

public void setSession(IoSession session) {
	this.session = session;
}

public byte getStartState() {
	return startState;
}

public void setStartState(byte startState) {
	this.startState = startState;
}

public byte getStopReason() {
	return stopReason;
}

public void setStopReason(byte stopReason) {
	this.stopReason = stopReason;
}

public Long getStartTime() {
	return startTime;
}

public void setStartTime(Long startTime) {
	this.startTime = startTime;
}

public int getTradeId() {
	return tradeId;
}

public void setTradeId(int tradeId) {
	this.tradeId = tradeId;
}

public float getElec() {
	return elec;
}

public void setElec(float elec) {
	this.elec = elec;
}

public boolean isStopSuccessState() {
	return stopSuccessState;
}

public void setStopSuccessState(boolean stopSuccessState) {
	this.stopSuccessState = stopSuccessState;
}

 
 
}
