package minaTest.Client;


import java.math.BigInteger;
import java.nio.ByteBuffer;


;



public class TestCMDUtilsV1 {

	private static final byte HEAD_CODE_VALUE = (byte) 0xBE;
	private static final byte END_CODE_VALUE = (byte) 0xE0;

	public static byte[] start(String mac){
		byte[] msg = new byte[]{(byte)HEAD_CODE_VALUE,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x06,0x01,0x01,0x01,
				0x01,0x00,0x00,0x01,0x00,0x00,0x00,(byte)END_CODE_VALUE};
		
		initMac(msg, getByteArray(mac));
		initCRC(msg);
		return msg;
	}
	
	/**
	 * 把16进制的字符串转换为字节数组。
	 * @param hexString 16进制的字符串
	 * @return 返回字节数组
	 */
	public static byte[] getByteArray(String hexString) {
		
		byte[] tmpBytes= new BigInteger(hexString, 16).toByteArray();
		
		if(tmpBytes[0]==0){
			byte[] bytes = new byte[tmpBytes.length-1];
			System.arraycopy(tmpBytes, 1, bytes, 0, bytes.length);
			return bytes;
		}else{
			return tmpBytes;
		}
	}
	/**
	 * 初始化消息中的MAC信息(MAC信息在消息的1-6位置)。
	 * @param msg 存放消息的字节数组
	 * @param macBytes 存放MAC的字节数组
	 */
	private static void initMac(byte[] msg,byte[] macBytes){
		for(int i=0;i<macBytes.length;i++){
			msg[i+1] = macBytes[i];
		}
	}
	
	private static void initCRC(byte[] msg){
		int crc = 0;
		int sum = 0;
		for (int i = 0; i < msg.length-2; i++) {
			sum += msg[i];
		}
		//截取低位
		crc = ( sum & 255);
		//无符号整型回绕
		crc = crc > 0 ? crc : crc + 256;
		
		msg[msg.length-2] = (byte)crc;
	}
/**
* @Title: heart
* @author:张爽
* @Description: 心跳报文 
* @param @param mac
* @param @return    
* @return byte[]    
* @throws 
* @Date 2016年10月10日
 */
	public static byte[] heart(String mac){
		byte[] msg = new byte[]{(byte)HEAD_CODE_VALUE,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x01,0x01,0x01,0x02,
				0x07,0x00,(byte)END_CODE_VALUE};
		
		initMac(msg, Utils.getByteArray(mac));
		initCRC(msg);
		
		return msg;
	}

/**
* @Title: cmdTime 
* @author:张爽
* @Description:校时报文 
* @param mac 电桩mac 
* @return byte[] 二进制数组
* @throws 
* @Date 2016年10月17日
 */
public static byte[] cmdTime(String mac) {
	byte[] msg = new byte[]{(byte)HEAD_CODE_VALUE,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x01,0x01,0x02,0x01,
			0x05,0x00,(byte)END_CODE_VALUE};
	
	initMac(msg, Utils.getByteArray(mac));
	initCRC(msg);
	return msg;
}

/**
 * 初始化消息数组的时间戳。
 * @param bytes 消息的字节数组
 */
private static void initTime(byte[] msg){
//	long currentTime = (System.currentTimeMillis()+Calendar.getInstance().getTimeZone().getRawOffset()) / 1000;
	long currentTime = System.currentTimeMillis()/ 1000;
	byte[] tmp = Utils.getByteArray(Long.toHexString(currentTime));
	for(int i=0;i<tmp.length;i++){
		msg[12+i] = tmp[i];
	}
}
private static void initTimeEnd(byte[] msg){
//	long currentTime = (System.currentTimeMillis()+Calendar.getInstance().getTimeZone().getRawOffset()) / 1000;
	long currentTime = System.currentTimeMillis()/ 1000;
	byte[] tmp = Utils.getByteArray(Long.toHexString(currentTime));
	for(int i=0;i<tmp.length;i++){
		msg[13+i] = tmp[i];
	}
}

/**
 * 有Integer数值转化为其对应的byte数组，返回Integer对应的byte数组。
 * @param data 待转化Integer数值
 * @return 返回Integer对应的byte数组
 */
public static byte[] int2Bytes(long data){
	byte[] bytes = new byte[4];
	bytes[0] = (byte) (data & 0xff);
	bytes[1] = (byte) ((data & 0xff00) >> 8);
	bytes[2] = (byte) ((data & 0xff0000) >> 16);
	bytes[3] = (byte) ((data & 0xff000000) >> 24);
	
	return bytes;
}


public static byte[] int2Bytes2(long data){
	byte[] bytes = new byte[4];
	bytes[0] = (byte) (0xFF & data  );
	bytes[1] = (byte) (( 0xff00& data ) >> 8);
	bytes[2] = (byte) ((0xff0000&data ) >> 16);
	bytes[3] = (byte) (( 0xff000000&data) >> 24);
	//(0xff & bytes[0]) | (0xff00 & (bytes[1] << 8)) | (0xff0000 & (bytes[2] << 16)) | (0xff000000 & (bytes[3] << 24))
	return bytes;
}



public static void  initTradeId(byte[] msg,long data){
	byte[] tmp=int2Bytes(data);
	for(int i=0;i<tmp.length;i++){
		msg[16+i] = tmp[i];
	}
}
public static void  initTradeIdEnd(byte[] msg,long data){
	byte[] tmp=int2Bytes(data);
	for(int i=0;i<tmp.length;i++){
		msg[17+i] = tmp[i];
	}
}

/**
 * 由Float数转化为byte数组，返回Float数值对应的byte数组。
 * @param data 待转化数值
 * @return 返回Float数值对应的byte数组
 */
public static void  initElec(byte[] msg,float data){
	int intBits = Float.floatToIntBits(data);
	
	byte[] tmp=int2Bytes(intBits);
	for(int i=0;i<tmp.length;i++){
		msg[20+i] = tmp[i];
	}
}
public static void  initElecEnd(byte[] msg,float data){
	int intBits = Float.floatToIntBits(data);
	
	byte[] tmp=int2Bytes(intBits);
	for(int i=0;i<tmp.length;i++){
		msg[21+i] = tmp[i];
	}
}
public static void  initCurrent(byte[] msg,float data){
	int intBits = Float.floatToIntBits(data);
	
	byte[] tmp=int2Bytes(intBits);
	for(int i=0;i<tmp.length;i++){
		msg[28+i] = tmp[i];
	}
}
public static void  initPower(byte[] msg,float data){
	int intBits = Float.floatToIntBits(data);
	
	byte[] tmp=int2Bytes(intBits);
	for(int i=0;i<tmp.length;i++){
		msg[24+i] = tmp[i];
	}
}

/**
* @Title: instance 
* @author:张爽
* @Description: 即时信息 
* @param mac 电桩mac
* @param electricity 电量
* @param current 电流
* @param power 电压
* @return byte[]    
* @throws 
* @Date 2016年10月18日
 */
public static  byte[] instance(String mac, float electricity, float current,
		float power, int id) {
	byte[] msg = new byte[]{(byte)HEAD_CODE_VALUE,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x14,0x01,0x03,0x01,
			0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,(byte)END_CODE_VALUE};
	initMac(msg, Utils.getByteArray(mac));
	initTime( msg);
	initTradeId(msg ,id);
	initElec(msg ,electricity);
	initPower(msg ,power);
	initCurrent(msg ,electricity);
	initCRC(msg);
	return msg;
}
public static void main(String[] args) {
	instance("A5123456785A", 0.25F, 0.25F,
			0.25F, 88156);
}

public static byte [] startRes(String mac, byte startState, int task_id) {
	byte[] msg = new byte[]{(byte)HEAD_CODE_VALUE,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x05,0x01,0x02,0x03,
			0x00,0x00,0x00,0x00,startState,0x00,(byte)END_CODE_VALUE};
	initTradeId1(msg ,task_id);
	initMac(msg, Utils.getByteArray(mac));
	initCRC(msg);
	return msg;
}
/*public static void main(String[] args) {
	startRes("A5123456785A", (byte)0x01, 84161);
}//0xbf|0xc1|0x48|0x01
*/private static void initTradeId1(byte[] msg, int task_id) {
	byte[] tmp=int2Bytes2(task_id);
	for(int i=0;i<tmp.length;i++){
		msg[12+i] = tmp[i];
	}
}

public static byte[]  gunCheck(String mac, byte b) {
	byte[] msg = new byte[]{(byte)HEAD_CODE_VALUE,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x01,0x01,0x02,0x02,
			b,0x00,(byte)END_CODE_VALUE};
	initMac(msg, Utils.getByteArray(mac));
	initCRC(msg);
	return msg;
}

public static byte[] stopCharging(String mac, int tradeId, float elec,
		byte b) {
	byte[] msg = new byte[]{(byte)HEAD_CODE_VALUE,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x0D,0x01,0x02,0x04,
			b,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,(byte)END_CODE_VALUE};
	initMac(msg, Utils.getByteArray(mac));
	initTimeEnd( msg);
	initTradeIdEnd(msg ,tradeId);
	initElecEnd(msg ,elec);
	initCRC(msg);
	return msg;
}




}
