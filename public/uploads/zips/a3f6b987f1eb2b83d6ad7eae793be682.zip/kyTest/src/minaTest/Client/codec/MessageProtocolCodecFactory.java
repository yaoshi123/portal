package minaTest.Client.codec;


import org.apache.mina.core.session.IoSession;
import org.apache.mina.filter.codec.ProtocolCodecFactory;
import org.apache.mina.filter.codec.ProtocolDecoder;
import org.apache.mina.filter.codec.ProtocolEncoder;

public class MessageProtocolCodecFactory implements ProtocolCodecFactory {

	  private ProtocolEncoder encoder;
      private ProtocolDecoder decoder;
      
     
     public MessageProtocolCodecFactory()
     {
         encoder = new MessageEncoder();
         decoder = new MessageDecoder();
     }
     
     @Override
     public ProtocolDecoder getDecoder(IoSession arg0) throws Exception {
         return decoder;
     }
 
     @Override
     public ProtocolEncoder getEncoder(IoSession arg0) throws Exception {
         return encoder;
     }
}
