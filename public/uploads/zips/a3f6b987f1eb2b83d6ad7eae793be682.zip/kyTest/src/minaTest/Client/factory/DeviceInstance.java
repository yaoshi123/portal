package minaTest.Client.factory;

import java.util.HashMap;
import java.util.Map;

import minaTest.Client.ChargingThread;
import minaTest.Client.HeartThread;

import org.apache.mina.core.session.IoSession;


public class DeviceInstance {
	
	private static DeviceInstance deviceInstance=null;
	private static Map<String , Device> deviceMap = new HashMap<String , Device>();
	private static Map<String , ChargingThread> chargingThreadMap=new HashMap<String, ChargingThread>();
	private static Map<String , HeartThread> heartThreadMap=new HashMap<String, HeartThread>();
	
	private DeviceInstance(){}
	public static synchronized DeviceInstance getInstance(){
		if(null==deviceInstance){
			deviceInstance=new DeviceInstance();
		}
		return deviceInstance;
	} 
	
	/**
	 * 充电桩登陆处理�?
	 * @param mac 桩的MAC地址
	 * @param session 桩与主站服务器之间�?信的通信通道
	 */
	public void login(String mac,IoSession session){
		Device device = new Device();
		device.setMac(mac.toUpperCase());
		device.setSession(session);
		deviceMap.put(mac.toUpperCase(),device);
	}
	
	public void login1(String mac,IoSession session){
		Device device = DeviceInstance.getInstance().getDeviceByMAC(mac);
		if(null==device){
			device=new Device();
		}
		device.setMac(mac.toUpperCase());
		device.setSession(session);
		deviceMap.put(mac.toUpperCase(),device);
	}
	public void setDevice(String mac,Device device){
		deviceMap.put(mac.toUpperCase(),device);
	}
	
	/**
	 * 通过MAC地址拿到其对应的Device对象�?
	 * @param mac 桩的MAC地址
	 * @return 返回MAC对应的Device对象
	 */
	public Device getDeviceByMAC(String mac){
		return deviceMap.get(mac);
	}
	
	/**
	 * 通过session对象拿到其对应的桩的MAC地址�?
	 * @param session  IoSession实例，即桩与主站服务器之间的通信通道
	 * @return 返回通信通道�?��的桩MAC地址
	 */
	public String getMacBySession(IoSession session){
		Device device = null;
		String mac = "";
		for (Map.Entry<String , Device> m : deviceMap.entrySet()) {
			device = m.getValue();
			if(session == device.getSession()){
				return m.getKey();
			}
		}
		return mac;
	}
	
	/**
	 * 清除内存中指定充电桩的对象�?
	 * @param mac 桩MAC地址
	 */
	public void clear(String mac){
		Device device = getDeviceByMAC(mac);
		if(device!=null){
			device.getSession().close(true);
		}
		deviceMap.remove(mac);
	}
	public static ChargingThread getChargingThreadMap(String mac) {
		return chargingThreadMap.get(mac);
	}
	public static void setChargingThreadMap(ChargingThread chargingThread,String mac) {
		chargingThreadMap.put(mac.toUpperCase(),chargingThread);
	}
	public static void cleanChargingThread(String mac) {
		chargingThreadMap.remove(mac);
	}
	public static void setHeartThreadMap(HeartThread neartThread,String mac) {
		heartThreadMap.put(mac.toUpperCase(),neartThread);
	}
	public static void cleanHeartThread(String mac) {
		heartThreadMap.remove(mac);
	}
	public static HeartThread getHeartThreadMap(String mac) {
		return heartThreadMap.get(mac);
	}
	
	
 
}
/*private static SingletonClass instance=null;
public static　synchronized　SingletonClass getInstance()
{
    if(instance==null)
    {
           instance=new SingletonClass();
    }
    return instance;
}
private SingletonClass(){
}*/