package minaTest.Client;



import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.HashMap;
import java.util.Map;

import  minaTest.Client.Const;



public class Utils {


	/**
	 * 把以16进制存放的字节数组转化为对应的从高到底位的16进制字符串，中间以|分隔。
	 * @param msg 存放16进制的字节数组
	 * @return 返回16进制的字符串
	 */
	public static String byteArrayToHexStr(byte[] msg){
		StringBuffer sb = new StringBuffer();
		for(byte obj:msg){
			int temp =obj & 0xff;
			if(temp<16)
				sb.append("0x").append("0"+Integer.toHexString(temp)).append("|");
			else
				sb.append("0x").append(Integer.toHexString(temp)).append("|");
		}
		return sb.toString();
	}
	
	/**
	 * 把两字节的16进制转化成对应的10进制数。
	 * @param higLen 16进制高位
	 * @param lowLen 16进制低位
	 * @return 返回两字节16进制对应的10进制数
	 */
	private static int getLenV1(int higLen,int lowLen){
		if(higLen<0)
			higLen +=256;
		
		if(lowLen<0)
			lowLen+=256;
		
		return higLen*16*16+lowLen;
	}
	/**
	 * 由byte数组转化为Integer数值，返回byte数组对应的Integer数值(适用于byte数组低位在前，高位在后的)。
	 * @param bytes 待转化byte数组
	 * @return 返回byte数组对应的Integer数值
	 */
	public static int bytes2Int(byte[] bytes){
		return (0xff & bytes[0]) | (0xff00 & (bytes[1] << 8)) | (0xff0000 & (bytes[2] << 16)) | (0xff000000 & (bytes[3] << 24));
	}
	

	/**
	 * 校验桩第一版本报文是否合法，若合法，返回真，若非法，返回假。
	 * @param msg 待检验报文
	 * @return 返回报文的合法性，合法返回真，非法返回假
	 */
	public static boolean validateV1(byte[] msg) {
		//报文最小长度为14(没有数据内容时)
		if (msg.length < 14) {
			return false;
		}
		//报文头是否正确
		if (msg[Const.HEAD_OFFSET] != (byte)Const.HEAD_CODE_VALUE)
			return false;
		//报文尾是否正确
		if(msg[msg.length-1]!=(byte)Const.END_CODE_VALUE)
			return false;
		//长度索引是否与报文实际长度相符
		if (getLenV1(msg[Const.CMD_HIG_LEN_INDEX],msg[Const.CMD_LOW_LEN_INDEX])!=msg.length-Const.MIN_DATAGRAM_LENGTH) {
			return false;
		}
		//CRC和校验(CRC位前所有位的和)
		byte[] tmpBytes = new byte[msg.length - 2];
		System.arraycopy(msg, 0, tmpBytes, 0, tmpBytes.length);

		int sum = 0;
		for (int i = 0; i < tmpBytes.length; i++) {
			sum += tmpBytes[i];
		}
		sum = sum % 256;
		sum = sum < 0 ? sum + 256 : sum;

		byte crc = (byte) sum;

		if (msg[msg.length - 2] != crc)
			return false;

		return true;
	}
	
	
	
	public static Map<String, byte[]> consumeDataByRule(byte[] msg) {
		Map<String, byte[]> resultMap = new HashMap<String, byte[]>();
		int dataLen = 0;
		if(msg[0]==(byte)Const.HEAD_CODE_VALUE){//以0xBE打头，可能取出完整的报文
			if(msg.length>=9){//包含了完整的数据域长度位
				dataLen = getLenV1(msg[7], msg[8]);//取出数据域长度
				/*if(dataLen>CMDConstantsV1.V1_MAX_LEN){
					//第一版的每条报文数据长度最大的为13
					resultMap.put("clear", new byte[]{});
					return resultMap;
				}*/
				if(msg.length==dataLen+14){//表示根据长度位能正好取出一条完整的报文
					if(validateV1(msg)){//取出完整的报文是合法的
						resultMap.put("CMD", msg);
						resultMap.put("CMD1", new byte[]{});
						return resultMap;
					}else{//取出的完整报文不合法，需清空session。
						resultMap.put("clear", new byte[]{});
						return resultMap;
					}
				}else if(msg.length>dataLen+14){//能取出一条完整的报文，仍有剩余
					byte[] msgOnlyOne = new byte[dataLen+14];
					System.arraycopy(msg, 0, msgOnlyOne, 0, msgOnlyOne.length);//把该完整信息拷到msgOnlyOne中去。
					if(validateV1(msgOnlyOne)){//取出完整的报文是合法的
						byte[] tmpMsg = new byte[msg.length-msgOnlyOne.length];//存放取出一条完整的合法信息后剩下的残值
						System.arraycopy(msg, msgOnlyOne.length, tmpMsg, 0, tmpMsg.length);
						resultMap.put("CMD", msgOnlyOne);
						resultMap.put("CMD1", tmpMsg);
						return resultMap;
					}else{//取出的完整报文不合法，需清空session。
						resultMap.put("clear", new byte[]{});
						return resultMap;
					}
				}else{//根据长度取不出完整的报文，放入session
					resultMap.put("CMD1", msg);
					return resultMap;
				}
			}else{//可能合法，但不包含完整的数据域长度位
				resultMap.put("CMD1", msg);
				return resultMap;
			}
		}
		return resultMap;
		
		}
	
	
	
	public static byte[] startChargeReq(String mac,int taskId){
		byte[] msg = new byte[]{(byte)Const.HEAD_CODE_VALUE,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x04,0x00,0x02,0x03,
				0x00,0x00,0x00,0x00,0x00,(byte)Const.END_CODE_VALUE};
		
		initMac(msg, Utils.getByteArray(mac));
		byte[] taskIds = Utils.int2Bytes(taskId);
		for(int i=0;i<taskIds.length;i++){
			msg[msg.length-(6-i)] = taskIds[i];
		}
		initCRC(msg);
		
		return msg;
	}
	
	/*public static void main(String[] args) {
		
		System.out.println(Utils.byteArrayToHexStr(startChargeReq("60C5A860D8A6",895675)));
	}*/
	
	
	private static void initCRC(byte[] msg){
		int crc = 0;
		int sum = 0;
		for (int i = 0; i < msg.length-2; i++) {
			sum += msg[i];
		}
		//截取低位
		crc = ( sum & 255);
		//无符号整型回绕
		crc = crc > 0 ? crc : crc + 256;
		
		msg[msg.length-2] = (byte)crc;
	}
	
	
	public static byte[] int2Bytes(long data){
		byte[] bytes = new byte[4];
		bytes[0] = (byte) (data & 0xff);
		bytes[1] = (byte) ((data & 0xff00) >> 8);
		bytes[2] = (byte) ((data & 0xff0000) >> 16);
		bytes[3] = (byte) ((data & 0xff000000) >> 24);
		
		return bytes;
	}
	
	
	
	public static byte[] getByteArray(String hexString) {
		
		byte[] tmpBytes= new BigInteger(hexString, 16).toByteArray();
		
		if(tmpBytes[0]==0){
			byte[] bytes = new byte[tmpBytes.length-1];
			System.arraycopy(tmpBytes, 1, bytes, 0, bytes.length);
			return bytes;
		}else{
			return tmpBytes;
		}
	}
	
	private static void initMac(byte[] msg,byte[] macBytes){
		for(int i=0;i<macBytes.length;i++){
			msg[i+1] = macBytes[i];
		}
	}

	/**
	 * 由byte数组转换为其对应的16进制字符串，返回byte数组对应的16进制字符串。
	 * @param bytes byte数组对象
	 * @return 返回byte数组对应的16进制字符串
	 */
	public static String hexByteToString(byte[] bytes){
		StringBuffer result = new StringBuffer();
		for (int i = 0; i < bytes.length; i++) {
//			result += Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1);
			result.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
		}
		return result.toString().toUpperCase();
	}

	/**
	 * 把4字节byte数组转化为int型数值(适用于byte数组高位在前，低位在后的)。
	 * @param src 待转化Integer数组
	 * @return 返回高位在前，低位在后的Integer数值
	 */
	public static int bytesToIntHs(byte[] src) {  
		return (int) ( ((src[0] & 0xFF)<<24)|((src[1] & 0xFF)<<16)|((src[2] & 0xFF)<<8)|(src[3] & 0xFF));
	}
	/**
	 * 把4字节byte数组转化为int型数值(适用于byte数组高位在前，低位在后的)。
	 * @param src 待转化Integer数组
	 * @return 返回高位在前，低位在后的Integer数值
	 */
	public static int bytesToIntH(byte[] src) {  
		return (int) (((src[0] & 0xFF)<<0)|((src[1] & 0xFF)<<8)|((src[2] & 0xFF)<<16)|((src[3] & 0xFF)<<24));
	}
	public static void main(String[] args) {
		System.out.println(bytesToIntH(new byte[]{71,73,1,0} ));
	}

	public static byte[] int2BytesKY(int data){
		byte[] bytes = new byte[4];
		bytes[0] = (byte) (data >> 24 & 0xff);
		bytes[1] = (byte) (data >> 16 & 0xff);
		bytes[2] = (byte) (data >> 8  & 0xff);
		bytes[3] = (byte) (data & 0xff);
		
		return bytes;
	}
	
}
