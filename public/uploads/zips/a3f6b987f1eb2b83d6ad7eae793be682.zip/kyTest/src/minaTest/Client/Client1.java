package minaTest.Client;

import java.net.InetSocketAddress;

import minaTest.Client.codec.MessageProtocolCodecFactory;
import minaTest.Client.factory.Device;
import minaTest.Client.factory.DeviceInstance;

import org.apache.mina.core.buffer.IoBuffer;
import org.apache.mina.core.future.ConnectFuture;
import org.apache.mina.core.session.IoSession;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.transport.socket.nio.NioSocketConnector;


public class Client1 {

	 public static final String HOST = "101.201.54.116";  
	//public static final String HOST = "";  
     
	    public static final int PORT = 9494;  
	      
	    public static void main(String[] args) {  
/*	        //创建连接器.  
	    NioSocketConnector connector = new NioSocketConnector();    
	        connector.getSessionConfig().setUseReadOperation(true);
	        connector.getSessionConfig().setReceiveBufferSize(10240);   // 设置接收缓冲区的大小  
	        connector.getSessionConfig().setSendBufferSize(10240);// 设置输出缓冲区的大小  
	        connector.getFilterChain().addLast("codec",  
	                new ProtocolCodecFilter(new MessageProtocolCodecFactory()));  
	        //添加业务理器.  
	        connector.setHandler(new TimeClientHandler());  
	        IoSession session = null;  
	        try {  
	            //创建连接.  
	            ConnectFuture future = connector.connect(new InetSocketAddress(HOST, PORT));  
	            // 等待连接创建完成  
	            future.awaitUninterruptibly();  
	            session = future.getSession();  
	            session.write(IoBuffer.wrap(TestCMDUtilsV1.start("60C5A860D8A6")));
	          //登录成功记录
				DeviceInstance.getInstance().login("60C5A860D8A6", session);
				Device device=DeviceInstance.getInstance().getDeviceByMAC("60C5A860D8A6");
				device.setGunStatus(true);
				device.setStartState((byte)0x01);
				device.setStopSuccessState(true);
				//device.setInstance((byte) 0x01);
	            System.out.println("客户端向服务器发送消息" );;  
	        } catch (Exception e) {  
	            System.out.println("客户端发送消息失败!");  
	        }  
	        //等待连接断开, 即线程阻塞在这里, 一直等到服务器关闭此session后, 线程才会继续执行.  
	        session.getCloseFuture().awaitUninterruptibly();  
	        //释放资源.  
	        connector.dispose(); 
	        */
	      
	       //设置电桩实例参数
	       /* Device device=new Device();
	        device.setMac("010203040506");
	        device.setGunStatus(true);
			device.setStartState((byte)0x01);
			device.setStopSuccessState(true);
	        DeviceInstance.getInstance().setDevice(device.getMac(), device);
	    	ClientThread client =new ClientThread(HOST, PORT, device.getMac(),device);
	    	
	    	client.run();
	    	System.out.println("第1个电桩----------------------------------------------");
	    	try {
				Thread.sleep(6000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}*/
	    	
	    	/*System.out.println(Integer.valueOf("60C5A860C014"));
	    	System.out.println(Integer.valueOf("060204020301"));
	    	System.out.println(Integer.valueOf("060204020301"));*/
    	Device device2=new Device();
	        device2.setMac("60C5A860C011");
	        device2.setGunStatus(true);
			device2.setStartState((byte)0x01);
			device2.setStopSuccessState(true);
	        DeviceInstance.getInstance().setDevice(device2.getMac(), device2);
	    	
	    	ClientThread client2 =new ClientThread(HOST, PORT, device2.getMac(),device2);
	    	client2.run();
	    	System.out.println("第2个电桩----------------------------------------------");
	    	try {
				Thread.sleep(6000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    	/**
	    	Device device3=new Device();
	    	device3.setMac("60C5A860C011");
	    	device3.setGunStatus(true);
	    	device3.setStartState((byte)0x01);
	    	device3.setStopSuccessState(true);
	    	DeviceInstance.getInstance().setDevice(device3.getMac(), device3);
	    	
	    	ClientThread client3 =new ClientThread(HOST, PORT, device3.getMac(),device3);
	    	client3.run();
	    	System.out.println("第3个电桩----------------------------------------------");
	    	
	    	try {
	    		Thread.sleep(6000);
	    	} catch (InterruptedException e) {
	    		// TODO Auto-generated catch block
	    		e.printStackTrace();
	    	}
	    	/*
	    	Device device4=new Device();
	    	device4.setMac("60C5A860C012");
	    	device4.setGunStatus(true);
	    	device4.setStartState((byte)0x01);
	    	device4.setStopSuccessState(true);
	    	DeviceInstance.getInstance().setDevice(device4.getMac(), device4);
	    	
	    	ClientThread client4 =new ClientThread(HOST, PORT, device4.getMac(),device4);
	    	client4.run();
	    	System.out.println("第4个电桩----------------------------------------------");
	    	try {
	    		Thread.sleep(6000);
	    	} catch (InterruptedException e) {
	    		// TODO Auto-generated catch block
	    		e.printStackTrace();
	    	}
	    	
	    	Device device5=new Device();
	    	device5.setMac("60C5A860C013");
	    	device5.setGunStatus(true);
	    	device5.setStartState((byte)0x01);
	    	device5.setStopSuccessState(true);
	    	DeviceInstance.getInstance().setDevice(device5.getMac(), device5);
	    	
	    	ClientThread client5 =new ClientThread(HOST, PORT, device5.getMac(),device5);
	    	client5.run();
	    	System.out.println("第5个电桩----------------------------------------------");
	    	
	    	try {
	    		Thread.sleep(6000);
	    	} catch (InterruptedException e) {
	    		// TODO Auto-generated catch block
	    		e.printStackTrace();
	    	}
	    	
	    	Device device6=new Device();
	    	device6.setMac("60C5A860C014");
	    	device6.setGunStatus(true);
	    	device6.setStartState((byte)0x01);
	    	device6.setStopSuccessState(true);
	    	DeviceInstance.getInstance().setDevice(device6.getMac(), device6);
	    	
	    	ClientThread client6=new ClientThread(HOST, PORT, device6.getMac(),device6);
	    	client6.run();
	    	System.out.println("第6个电桩----------------------------------------------");
	    	*/
	    }
	}  