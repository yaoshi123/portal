package minaTest.Client;


import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import minaTest.Client.factory.Device;
import minaTest.Client.factory.DeviceInstance;

import org.apache.mina.core.buffer.IoBuffer;
import org.apache.mina.core.service.IoHandlerAdapter;
import org.apache.mina.core.session.IoSession;



public class TimeClientHandler extends IoHandlerAdapter {  
    private static final byte HEAD_CODE_VALUE = (byte) 0xBE;
   
	// 当客户端连接进入时  
    @Override  
    public void sessionOpened(IoSession session) throws Exception { 
        System.out.println("incomming 客户端: " + session.getRemoteAddress());  
        
    }  
  
    @Override  
    public void exceptionCaught(IoSession session, Throwable cause)  
            throws Exception {  
        System.out.println("客户端发送信息异常....");  
    }  
  
    // 当客户端发送消息到达时  
    @Override  
    public void messageReceived(IoSession session, Object message)  
            throws Exception {  
  
        System.out.println("服务器返回的数据：" + message.toString());  
       // IoBuffer receivedMsg=(IoBuffer) message;
		byte[] msg = (byte[]) message;
		//receivedMsg.get(msg);
		System.out.println("待处理数据为" + Utils.byteArrayToHexStr(msg));
		Map<String, byte[]> resultMap = null;
		resultMap = Utils.consumeDataByRule(msg);
		if(resultMap.get("CMD1")==null){
			byte[] cmd = resultMap.get("CMD");
			if(cmd[0]==(byte)HEAD_CODE_VALUE){
				byte[] macs = new byte[6];
				System.arraycopy(msg, 1, macs, 0, macs.length);
				String mac = Utils.hexByteToString(macs);
				if(msg[Const.CMD1_INDEX]==Const.CMD1_1_VALUE && msg[Const.CMD2_INDEX]==Const.CMD2_1_VALUE){
					Thread thread =new HeartThread(session, mac);
					thread.start();
				}
				
			}
		}else{
			byte[] cmd = resultMap.get("CMD");
			if(cmd[0]==(byte)HEAD_CODE_VALUE){
				byte[] macs = new byte[6];
				System.arraycopy(msg, 1, macs, 0, macs.length);
				String mac = Utils.hexByteToString(macs);
				Device device = DeviceInstance.getInstance().getDeviceByMAC(mac);
				if(msg[Const.CMD1_INDEX]==Const.CMD1_1_VALUE && msg[Const.CMD2_INDEX]==Const.CMD2_1_VALUE){
					System.out.println("电桩"+mac+"第二次登录回复");
					System.out.println("发送校时" + Utils.byteArrayToHexStr(TestCMDUtilsV1.cmdTime(mac)));
					if(0x01==msg[12]){
						//登录成功启动心跳
						HeartThread thread =new HeartThread(session, mac);
						thread.start();
						DeviceInstance.setHeartThreadMap(thread, mac);
					}else{
						//登录失败重新登录
						session.write(IoBuffer.wrap(TestCMDUtilsV1.start(mac)));  
					}
				}
				if(msg[Const.CMD1_INDEX]==Const.CMD1_1_VALUE && msg[Const.CMD2_INDEX]==Const.CMD2_2_VALUE){
					System.out.println("电桩"+mac+"心跳回复");
				}
				if(msg[Const.CMD1_INDEX]==Const.CMD1_2_VALUE && msg[Const.CMD2_INDEX]==Const.CMD2_1_VALUE){
					System.out.println("电桩"+mac+"校时回复");
					if(0x01==msg[16]){
						byte[] tmp = new byte[4];
						System.arraycopy(msg, 12, tmp, 0, tmp.length);
						int ti = Utils.bytesToIntHs(tmp);//任务单号
						System.out.println(ti);
						System.out.println(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date(ti)));
					}else{
						session.write(IoBuffer.wrap(TestCMDUtilsV1.cmdTime(mac)));//发送校时
						System.out.println("发送校时" + Utils.byteArrayToHexStr(TestCMDUtilsV1.cmdTime(mac)));
					}
				}
				if(msg[Const.CMD1_INDEX]==Const.CMD1_2_VALUE && msg[Const.CMD2_INDEX]==Const.CMD2_3_VALUE){
					byte[] tmp = new byte[4];
					System.arraycopy(msg, 12, tmp, 0, tmp.length);
					int task_id = Utils.bytesToIntH(tmp);//任务单号
					session.write(IoBuffer.wrap(TestCMDUtilsV1.startRes(mac,device.getStartState(),task_id)));
					System.out.println("充电开始" + Utils.byteArrayToHexStr(TestCMDUtilsV1.startRes(mac,device.getStartState(),task_id)));
					if(device.getStartState()==(byte)0x01){
						if(null==DeviceInstance.getChargingThreadMap(mac)){
							device.setStartTime(System.currentTimeMillis()/1000);
							device.setTradeId(task_id);
							ChargingThread thread =new ChargingThread(session, mac);
							thread.start();
							DeviceInstance.setChargingThreadMap(thread, mac);
							System.out.println("电桩"+mac+"开始充电");
						}else{
							System.out.println("电桩"+mac+"开始充电---------------------------");
						}
						
					}
					
				}
				
				if(msg[Const.CMD1_INDEX]==Const.CMD1_2_VALUE && msg[Const.CMD2_INDEX]==Const.CMD2_2_VALUE){
					System.out.println("电桩"+mac+"插枪请求");
					if(device.isGunStatus()){
						System.out.println("插枪成功" + Utils.byteArrayToHexStr(TestCMDUtilsV1.gunCheck(mac,(byte)0x01)));
						session.write(IoBuffer.wrap(TestCMDUtilsV1.gunCheck(mac,(byte)0x01)));
					}else{
						System.out.println("插枪失败" + Utils.byteArrayToHexStr(TestCMDUtilsV1.gunCheck(mac,(byte)0x02)));
						
						session.write(IoBuffer.wrap(TestCMDUtilsV1.gunCheck(mac,(byte)0x02)));
					}
				}
				if(msg[Const.CMD1_INDEX]==Const.CMD1_2_VALUE && msg[Const.CMD2_INDEX]==Const.CMD2_4_VALUE){
					System.out.println("电桩"+mac+"发送停止充电");
					if(device.isStopSuccessState()){
						System.out.println("停止充电----" + Utils.byteArrayToHexStr(TestCMDUtilsV1.stopCharging(mac,device.getTradeId(),device.getElec(),(byte)0x01)));
						session.write(IoBuffer.wrap(TestCMDUtilsV1.stopCharging(mac,device.getTradeId(),device.getElec(),(byte)0x01)));
						DeviceInstance.getChargingThreadMap(mac).stop();
						DeviceInstance.cleanChargingThread(mac);
					}else{
						System.out.println("停止充电" + Utils.byteArrayToHexStr(TestCMDUtilsV1.stopCharging(mac,device.getTradeId(),device.getElec(),(byte)0x02)));
						
						session.write(IoBuffer.wrap(TestCMDUtilsV1.stopCharging(mac,device.getTradeId(),device.getElec(),(byte)0x02)));
					}
					
				}
				if(msg[Const.CMD1_INDEX]==Const.CMD1_3_VALUE && msg[Const.CMD2_INDEX]==Const.CMD2_1_VALUE){
					if(0x01==msg[12]){
						System.out.println("电桩"+mac+"即时信息停止");
						if(device.isStopSuccessState()){
							session.write(IoBuffer.wrap(TestCMDUtilsV1.stopCharging(mac,device.getTradeId(),device.getElec(),(byte)0x01)));
							DeviceInstance.getChargingThreadMap(mac).stop();
							DeviceInstance.cleanChargingThread(mac);
						}else{
							session.write(IoBuffer.wrap(TestCMDUtilsV1.stopCharging(mac,device.getTradeId(),device.getElec(),(byte)0x02)));
						}
					}
					System.out.println("电桩"+mac+"即时信息回复");
				}
				if(msg[Const.CMD1_INDEX]==Const.CMD1_3_VALUE && msg[Const.CMD2_INDEX]==Const.CMD2_2_VALUE){
					System.out.println("电桩"+mac+"充电停止回复");
				}
			}
			msg = resultMap.get("CMD1");
		}
		
    }  
  
    @SuppressWarnings("static-access")
	@Override  
    public void sessionClosed(IoSession session) throws Exception {  
        System.out.println("客户端与服务端断开连接....."); 
        //获取mac
        String mac=DeviceInstance.getInstance().getMacBySession(session);
        //获取电桩实例
        Device device=DeviceInstance.getInstance().getDeviceByMAC(mac);
        //关闭之前开启线程
        DeviceInstance.getInstance().getHeartThreadMap(mac).stop();
        DeviceInstance.getInstance().getChargingThreadMap(mac).stop();
        //创建连接
        new ClientThread("127.0.0.1", 9494,mac,device);
        
        
    }  
  
    @Override  
    public void sessionCreated(IoSession session) throws Exception {  
        System.out .println("one Client Connection" + session.getRemoteAddress());  
        
    }  
  
}  