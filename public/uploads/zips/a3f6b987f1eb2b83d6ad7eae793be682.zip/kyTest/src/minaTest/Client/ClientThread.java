package minaTest.Client;

import java.net.InetSocketAddress;

import minaTest.Client.codec.MessageProtocolCodecFactory;
import minaTest.Client.factory.Device;
import minaTest.Client.factory.DeviceInstance;

import org.apache.mina.core.buffer.IoBuffer;
import org.apache.mina.core.future.ConnectFuture;
import org.apache.mina.core.session.IoSession;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.transport.socket.nio.NioSocketConnector;

public class ClientThread extends Thread {
/*	public static final String HOST = "127.0.0.1";  
    
    public static final int PORT = 9494;  */
      
    private String host;
    private int  port;
    private String mac ;
    private Device device ;
    
    
    
	public ClientThread(String host, int port, String mac ,Device device) {
		super();
		this.host = host;
		this.port = port;
		this.mac = mac;
		this.device=device;
		//DeviceInstance.getInstance().s
	}



	public void run(){
		//创建连接器.  
		NioSocketConnector connector = new NioSocketConnector();    
	    connector.getSessionConfig().setUseReadOperation(true);
	    connector.getSessionConfig().setReceiveBufferSize(10240);   // 设置接收缓冲区的大小  
	    connector.getSessionConfig().setSendBufferSize(10240);// 设置输出缓冲区的大小  
	    connector.getFilterChain().addLast("codec",  
	            new ProtocolCodecFilter(new MessageProtocolCodecFactory()));  
	    //添加业务理器.  
	    connector.setHandler(new TimeClientHandler());  
	    IoSession session = null;  
	    try {  
	        //创建连接.  
	        ConnectFuture future = connector.connect(new InetSocketAddress(host, port));  
	        // 等待连接创建完成  
	        future.awaitUninterruptibly();  
	        session = future.getSession();  
	        session.write(IoBuffer.wrap(TestCMDUtilsV1.start(mac)));
	      //登录成功记录
			DeviceInstance.getInstance().login1(mac, session);
			/*Device device=DeviceInstance.getInstance().getDeviceByMAC(mac);
			device.setGunStatus(true);
			device.setStartState((byte)0x01);
			//device.setInstance((byte) 0x01);
*/	        System.out.println("客户端向服务器发送消息" );;  
	    } catch (Exception e) {  
	        System.out.println("客户端发送消息失败!");  
	    }  
	    //等待连接断开, 即线程阻塞在这里, 一直等到服务器关闭此session后, 线程才会继续执行.  
	    //session.getCloseFuture().awaitUninterruptibly();  
	    //释放资源.  
	   // connector.dispose();  
	}
}
