package minaTest.Client;

import minaTest.Client.factory.Device;
import minaTest.Client.factory.DeviceInstance;

import org.apache.mina.core.buffer.IoBuffer;
import org.apache.mina.core.session.IoSession;

public class ChargingThread extends Thread {
 private IoSession session;
 private String mac;

public ChargingThread(IoSession session,String mac) {
	super();
	this.session = session;
	this.mac = mac;
}

public void run(){
	for(int i=0;;i++ ){
		System.out.println("充电线程启动");
		Device device=DeviceInstance.getInstance().getDeviceByMAC(mac);
		try {
			Thread.sleep(8000);
		} catch (InterruptedException e1) {
			e1.printStackTrace();
		}
		
		//if (!device .isStopState()){
			float electricity=(System.currentTimeMillis()/1000-device.getStartTime())/100;
			float current=7.5F;
			float power =220.6F;
			device.setElec(electricity);
			System.out.println("即时信息----" + Utils.byteArrayToHexStr(TestCMDUtilsV1.instance(mac,electricity,current,power, device.getTradeId())));
			session.write(IoBuffer.wrap(TestCMDUtilsV1.instance(mac,electricity,current,power, device.getTradeId())));
		//}
		try {
			Thread.sleep(7000);
		} catch (InterruptedException e1) {
			e1.printStackTrace();
		}
		
		
		
	}
	
} 

 
}
