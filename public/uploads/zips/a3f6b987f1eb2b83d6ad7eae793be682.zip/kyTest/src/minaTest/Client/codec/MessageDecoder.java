package minaTest.Client.codec;

import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;

import org.apache.mina.core.buffer.IoBuffer;
import org.apache.mina.core.session.IoSession;
import org.apache.mina.filter.codec.ProtocolDecoder;
import org.apache.mina.filter.codec.ProtocolDecoderOutput;

public class MessageDecoder implements ProtocolDecoder {

    	 @Override
    		public void decode(IoSession session, IoBuffer in, ProtocolDecoderOutput out)
    				throws Exception {
    			
    			int limit = in.limit();
    			byte[] bytes = new byte[limit];
    			
    			in.get(bytes);
    			
    			out.write(bytes);
    		}

	
	@Override
	public void dispose(IoSession arg0) throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void finishDecode(IoSession arg0, ProtocolDecoderOutput arg1)
			throws Exception {
		// TODO Auto-generated method stub
		
	}
}
