package minaTest.Client;

public class  Const {
	

		/**
		 * 报文头位置索引。
		 */
		public static final int HEAD_OFFSET = 0;
		
		/**
		 * 控制位位置索引。
		 */
		public static final int CONTROL_BIT= 9;
		
		/**
		 * 一级指令码位置索引。
		 */
		public static final int CMD1_INDEX = 10;
		
		/**
		 * 二级指令码位置索引。
		 */
		public static final int CMD2_INDEX = 11;
		/**
		 * 最小报文总长度。
		 */
		public static final int MIN_DATAGRAM_LENGTH = 14;
		/**
		 * 报文长度高位索引位置。
		 */
		public static final int CMD_HIG_LEN_INDEX =7;
		/**
		 * 报文长度低位索引位置。
		 */
		public static final int CMD_LOW_LEN_INDEX =8;
		
		/**
		 * 报文头值。
		 */
//		public static final int HEAD_CODE_VALUE=0x68;
		public static final int HEAD_CODE_VALUE=0xBE;
		public static final int HEAD_CODE_VALUE_KY=0x68;

		/**
		 * 报文尾值。
		 */
//		public static final int END_CODE_VALUE=0x16;
		public static final int END_CODE_VALUE=0xE0;
		public static final int END_CODE_VALUE_KY=0x16;
		/**
		 * 一级命令码。
		 */
		public static final int CMD1_1_VALUE = 0x01;
		public static final int CMD1_2_VALUE = 0x02;
		public static final int CMD1_3_VALUE = 0x03;
		public static final int CMD1_4_VALUE = 0x04;
		public static final int CMD1_5_VALUE = 0x05;
		public static final int CMD1_6_VALUE = 0x06;
		
		/**
		 * 二级命令码。
		 */
		public static final int CMD2_1_VALUE = 0x01;
		public static final int CMD2_2_VALUE = 0x02;
		public static final int CMD2_3_VALUE = 0x03;
		public static final int CMD2_4_VALUE = 0x04;
		public static final int CMD2_5_VALUE = 0x05;
		public static final int CMD2_6_VALUE = 0x06;
		public static final int CMD2_7_VALUE = 0x07;
		public static final int CMD2_8_VALUE = 0x08;
		public static final int CMD2_9_VALUE = 0x09;
		public static final int CMD2_a_VALUE = 0x0a;
		public static final int CMD2_b_VALUE = 0x0b;
		
		/**
		 * 心跳超时时间(秒)。
		 */
		public static final int OUT_LINE_TIME = 300;
		
		/**
		 * 预约超时时间(秒)。
		 */
		public static final int YUYUE_OUT_TIME = 1800;
		/**
		 * 判断桩上报即时电量是否可以继续充电的标识位，含有此值，不能继续充电。
		 */
		public static final String PERFLAGSTOP = "perFlagStop";
		/**
		 * 处理粘包时，取放在IoSession中剩余报文的属性索引。
		 */
		public static final String MSGBUFFER = "message_buffer";
		/**
		 * 版本1报文中最大数据域长度。
		 */
		public static final int V1_MAX_LEN = 25;
		

}
