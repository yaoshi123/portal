package minaTest.Client;

import org.apache.mina.core.buffer.IoBuffer;
import org.apache.mina.core.session.IoSession;

public class HeartThread extends Thread {
 private IoSession session;
 private String mac;

public HeartThread(IoSession session,String mac) {
	super();
	session.write(IoBuffer.wrap(TestCMDUtilsV1.cmdTime(mac)));//发送校时
	this.session = session;
	this.mac = mac;
}

public void run(){
	session.write(IoBuffer.wrap(TestCMDUtilsV1.heart(mac)));
	for(int i=0;;i++ ){
		try {
			Thread.sleep(23000);
		} catch (InterruptedException e1) {
			e1.printStackTrace();
		}
		session.write(IoBuffer.wrap(TestCMDUtilsV1.heart(mac)));
		
	}
	
} 

 
}
