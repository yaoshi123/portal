package test;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
public class Weixin extends HttpServlet{
	 public void doGet(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException {
	        doPost(request, response);
	    }

	    /**
	     * The doPost method of the servlet. <br>
	     *
	     * This method is called when a form has its tag value method equals to post.
	     * 
	     * @param request the request send by the client to the server
	     * @param response the response send by the server to the client
	     * @throws ServletException if an error occurred
	     * @throws IOException if an error occurred
	     */
	    public void doPost(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException {
	    	
	    	 String token="coolWeixin";
	         String timestamp=request.getParameter("timestamp");
	         String nonce=request.getParameter("nonce");
	         String signature=request.getParameter("signature");
			String tmpStr;
			try {
				tmpStr = this.getSHA1(token, timestamp, nonce);
			} catch (NoSuchAlgorithmException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        /*if(tmpStr.equals(signature)){
	        	return true;
	        	
	        }else{
	        	return false;
	        }*/
		  // System.out.println("+++++++++++++++++++++tmpStr   "+tmpStr);
		     
		    
		        
	    }
	    
	    /**
	     * 用SHA1算法生成安全签名
	     * @param token 票据
	     * @param timestamp 时间戳
	     * @param nonce 随机字符串
	     * @param encrypt 密文
	     * @return 安全签名
	     * @throws NoSuchAlgorithmException 
	     * @throws AesException 
	     */
	    public  String getSHA1(String token, String timestamp, String nonce) throws NoSuchAlgorithmException  {
	            String[] array = new String[] { token, timestamp, nonce };
	            StringBuffer sb = new StringBuffer();
	            // 字符串排序
	            Arrays.sort(array);
	            for (int i = 0; i < 3; i++) {
	                sb.append(array[i]);
	            }
	            String str = sb.toString();
	            // SHA1签名生成
	            MessageDigest md = MessageDigest.getInstance("SHA-1");
	            md.update(str.getBytes());
	            byte[] digest = md.digest();

	            StringBuffer hexstr = new StringBuffer();
	            String shaHex = "";
	            for (int i = 0; i < digest.length; i++) {
	                shaHex = Integer.toHexString(digest[i] & 0xFF);
	                if (shaHex.length() < 2) {
	                    hexstr.append(0);
	                }
	                hexstr.append(shaHex);
	            }
	            return hexstr.toString();
	    }
}
