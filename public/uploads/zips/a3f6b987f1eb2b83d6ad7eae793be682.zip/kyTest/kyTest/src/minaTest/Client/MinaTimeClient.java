package minaTest.Client;

import java.net.InetSocketAddress;

import minaTest.Client.codec.MessageProtocolCodecFactory;
import minaTest.Client.factory.Device;
import minaTest.Client.factory.DeviceInstance;

import org.apache.mina.core.buffer.IoBuffer;
import org.apache.mina.core.future.ConnectFuture;
import org.apache.mina.core.session.IoSession;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.transport.socket.nio.NioSocketConnector;


public class MinaTimeClient {

	 public static final String HOST = "127.0.0.1";  
     
	    public static final int PORT = 7080;  
	      
	    public static void main(String[] args) {  
	        //创建连接器.  
	    NioSocketConnector connector = new NioSocketConnector();    
	        connector.getSessionConfig().setUseReadOperation(true);
	        connector.getSessionConfig().setReceiveBufferSize(10240);   // 设置接收缓冲区的大小  
	        connector.getSessionConfig().setSendBufferSize(10240);// 设置输出缓冲区的大小  
	        connector.getFilterChain().addLast("codec",  
	        new ProtocolCodecFilter(new MessageProtocolCodecFactory()));  
	        //添加业务理器.  
	        connector.setHandler(new TimeClientHandler());  
	        IoSession session = null;  
	        try {  
	            //创建连接.  
	            ConnectFuture future = connector.connect(new InetSocketAddress(HOST, PORT));  
	            // 等待连接创建完成  
	            future.awaitUninterruptibly();  
	            session = future.getSession();  
	            session.write(IoBuffer.wrap(TestCMDUtilsV1.start("60C5A860C010")));
	          //登录成功记录
				DeviceInstance.getInstance().login("60C5A860C010", session);
				Device device=DeviceInstance.getInstance().getDeviceByMAC("60C5A860C010");
				device.setGunStatus(true);
				device.setStartState((byte)0x01);
				device.setStopSuccessState(true);
				//device.setInstance((byte) 0x01);
	            System.out.println("客户端向服务器发送消息" );;  
	        } catch (Exception e) {  
	            System.out.println("客户端发送消息失败!");  
	        }  
	        //等待连接断开, 即线程阻塞在这里, 一直等到服务器关闭此session后, 线程才会继续执行.  
	        session.getCloseFuture().awaitUninterruptibly();  
	        //释放资源.  
	        connector.dispose(); 
	  /*      
	        //设置电桩实例参数
	        Device device=new Device();
	        device.setMac("60C5A860C010");
	        */
	    	
	    /*	ClientThread client =new ClientThread(HOST, PORT, "60C5A860C010");
	    	
	    	client.run();
	    	try {
				Thread.sleep(6000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    	
	    	
	    	ClientThread client1 =new ClientThread(HOST, PORT, "60C5A860D8A6");
	    	client1.run();*/
	    	
	    }
	}  